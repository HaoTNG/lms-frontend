import React from 'react'
import { Routes, Route } from 'react-router-dom'
import MainLayout from './layouts/MainLayout'
import AdminPage from './pages/AdminPage'
import TutorPage from './pages/TutorPage'
import MenteePage from './pages/MenteePage'
import UserPage from './pages/UserPage'

export default function App() {
  return (
    <MainLayout>
      <Routes>
        <Route path="/admin" element={<AdminPage />} />
        <Route path="/tutor" element={<TutorPage />} />
        <Route path="/mentee" element={<MenteePage />} />
        <Route path="/user" element={<UserPage />} />
      </Routes>
    </MainLayout>
  )
}